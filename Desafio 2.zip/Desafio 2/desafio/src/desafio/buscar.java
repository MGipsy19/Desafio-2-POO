package desafio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class buscar extends JFrame {

    private JPanel panelLibro;
    private JPanel panelRevista;
    private JPanel panelCD;
    private JPanel panelDVD;
    private JTextField txtIdMediateca;

    public buscar() {
        super("Buscar en Mediateca");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        txtIdMediateca = new JTextField(10);

        // Botón "Buscar"
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idMediateca = txtIdMediateca.getText();
                if (!idMediateca.isEmpty()) {
                    char tipoMaterial = Character.toLowerCase(idMediateca.charAt(0)); // Convertir a minúsculas antes de comparar
                    switch (tipoMaterial) {
                        case 'l':
                            abrirVentanaCampos("Libro");
                            break;
                        case 'r':
                            abrirVentanaCampos("Revista");
                            break;
                        case 'c':
                            abrirVentanaCampos("CD");
                            break;
                        case 'd':
                            abrirVentanaCampos("DVD");
                            break;
                        default:
                            // Manejar el caso si no coincide con ningún tipo de material
                            break;
                    }
                }
            }
        });

        // Botón "Reservar"
        JButton btnReservar = new JButton("Reservar");
        btnReservar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para reservar el material y volver a la ventana principal de Mediateca
                dispose();
            }
        });

        // Crear paneles
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnBuscar);
        panelBotones.add(btnReservar);

        panelLibro = crearPanelLibro();
        panelRevista = crearPanelRevista();
        panelCD = crearPanelCD();
        panelDVD = crearPanelDVD();

        // Organizar componentes en la ventana
        setLayout(new BorderLayout());
        JPanel panelIdMediateca = new JPanel();
        panelIdMediateca.add(new JLabel("ID Mediateca:"));
        panelIdMediateca.add(txtIdMediateca);
        add(panelIdMediateca, BorderLayout.NORTH);

        add(panelBotones, BorderLayout.CENTER);

        // Agregar los paneles pero inicialmente ocultos
        add(panelLibro, BorderLayout.SOUTH);
        add(panelRevista, BorderLayout.SOUTH);
        add(panelCD, BorderLayout.SOUTH);
        add(panelDVD, BorderLayout.SOUTH);
        panelLibro.setVisible(false);
        panelRevista.setVisible(false);
        panelCD.setVisible(false);
        panelDVD.setVisible(false);
    }

    private JPanel crearPanelLibro() {
        JPanel panelLibro = new JPanel(new GridLayout(0, 2));
        panelLibro.add(new JLabel("Código:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("Título:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("Autor:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("Número de Páginas:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("Editorial:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("ISBN:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("Año de Publicación:"));
        panelLibro.add(new JTextField());
        panelLibro.add(new JLabel("Unidades Disponibles:"));
        panelLibro.add(new JTextField());
        return panelLibro;
    }

    private JPanel crearPanelRevista() {
        JPanel panelRevista = new JPanel(new GridLayout(0, 2));
        panelRevista.add(new JLabel("Código:"));
        panelRevista.add(new JTextField());
        panelRevista.add(new JLabel("Título:"));
        panelRevista.add(new JTextField());
        panelRevista.add(new JLabel("Editorial:"));
        panelRevista.add(new JTextField());
        panelRevista.add(new JLabel("Periodicidad:"));
        panelRevista.add(new JTextField());
        panelRevista.add(new JLabel("Publicación:"));
        panelRevista.add(new JTextField());
        panelRevista.add(new JLabel("Unidades Disponibles:"));
        panelRevista.add(new JTextField());
        return panelRevista;
    }

    private JPanel crearPanelCD() {
        JPanel panelCD = new JPanel(new GridLayout(0, 2));
        panelCD.add(new JLabel("Código:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Nombre:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Título:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Artista:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Género:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Duración:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Número de Canciones:"));
        panelCD.add(new JTextField());
        panelCD.add(new JLabel("Unidades Disponibles:"));
        panelCD.add(new JTextField());
        return panelCD;
    }

    private JPanel crearPanelDVD() {
        JPanel panelDVD = new JPanel(new GridLayout(0, 2));
        panelDVD.add(new JLabel("Código:"));
        panelDVD.add(new JTextField());
        panelDVD.add(new JLabel("Título:"));
        panelDVD.add(new JTextField());
        panelDVD.add(new JLabel("Director:"));
        panelDVD.add(new JTextField());
        panelDVD.add(new JLabel("Duración:"));
        panelDVD.add(new JTextField());
        panelDVD.add(new JLabel("Género:"));
        panelDVD.add(new JTextField());
        return panelDVD;
    }

    private void mostrarPanelLibro() {
        panelLibro.setVisible(true);
        panelRevista.setVisible(false);
        panelCD.setVisible(false);
        panelDVD.setVisible(false);
    }

    private void mostrarPanelRevista() {
        panelLibro.setVisible(false);
        panelRevista.setVisible(true);
        panelCD.setVisible(false);
        panelDVD.setVisible(false);
    }

    private void mostrarPanelCD() {
        panelLibro.setVisible(false);
        panelRevista.setVisible(false);
        panelCD.setVisible(true);
        panelDVD.setVisible(false);
    }

    private void mostrarPanelDVD() {
        panelLibro.setVisible(false);
        panelRevista.setVisible(false);
        panelCD.setVisible(false);
        panelDVD.setVisible(true);
    }

    private void abrirVentanaCampos(String tipoMaterial) {
        JFrame ventanaCampos = new JFrame("Campos de " + tipoMaterial);
        ventanaCampos.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventanaCampos.setSize(400, 300);
        ventanaCampos.setLocationRelativeTo(null);

        // Crear y agregar los paneles de campos correspondientes al tipo de material
        JPanel panelCampos = new JPanel();
        switch (tipoMaterial) {
            case "Libro":
                panelCampos = crearPanelLibro();
                break;
            case "Revista":
                panelCampos = crearPanelRevista();
                break;
            case "CD":
                panelCampos = crearPanelCD();
                break;
            case "DVD":
                panelCampos = crearPanelDVD();
                break;
            default:
                break;
        }

        ventanaCampos.add(panelCampos);
        ventanaCampos.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new buscar().setVisible(true);
        });
    }
}
