package desafio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class borrar extends JFrame {

    private JTextField txtIdMaterial;

    public borrar() {
        super("Mediateca");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 150);
        setResizable(false);
        setLocationRelativeTo(null);

        // Campo de texto para ingresar el ID del material a borrar
        txtIdMaterial = new JTextField(10);

        // Botón "Borrar"
        JButton btnBorrar = new JButton("Borrar");
        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el ID del material ingresado por el usuario
                String idMaterial = txtIdMaterial.getText();
                
                // Aquí podrías implementar la lógica para buscar y borrar el material
                // utilizando el ID proporcionado
                
                // Mostrar un mensaje de confirmación de borrado
                JOptionPane.showMessageDialog(null, "Material con ID " + idMaterial + " ha sido borrado.", "Borrado Exitoso", JOptionPane.INFORMATION_MESSAGE);
                
                // Limpiar el campo de texto después de borrar
                txtIdMaterial.setText("");
                
                // Cerrar la ventana actual
dispose();

            }
        });

        // Organizar componentes en la ventana
        setLayout(new BorderLayout());
        JPanel panelIdMaterial = new JPanel();
        panelIdMaterial.add(new JLabel("ID Material a Borrar:"));
        panelIdMaterial.add(txtIdMaterial);
        add(panelIdMaterial, BorderLayout.NORTH);

        JPanel panelBotonBorrar = new JPanel();
        panelBotonBorrar.add(btnBorrar);
        add(panelBotonBorrar, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new borrar().setVisible(true);
        });
    }
}
