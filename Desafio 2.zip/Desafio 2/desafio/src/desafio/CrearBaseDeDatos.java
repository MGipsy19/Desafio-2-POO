/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafio;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CrearBaseDeDatos {

    public static void main(String[] args) {
        Connection conexion = null;
        Statement stmt = null;

        try {
            // Establecer la conexión con la base de datos
            conexion = DriverManager.getConnection("jdbc:sqlite:mediateca.db");
            
            // Crear las tablas
            stmt = conexion.createStatement();
            
            // Tabla para Libros
            String sqlLibros = "CREATE TABLE IF NOT EXISTS Libros (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "codigo TEXT NOT NULL," +
                    "titulo TEXT NOT NULL," +
                    "autor TEXT NOT NULL," +
                    "numero_paginas INTEGER NOT NULL," +
                    "editorial TEXT NOT NULL," +
                    "isbn TEXT NOT NULL," +
                    "anio_publicacion INTEGER NOT NULL," +
                    "unidades_disponibles INTEGER NOT NULL)";
            stmt.executeUpdate(sqlLibros);
            
            // Tabla para Revistas
            String sqlRevistas = "CREATE TABLE IF NOT EXISTS Revistas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "codigo TEXT NOT NULL," +
                    "titulo TEXT NOT NULL," +
                    "editorial TEXT NOT NULL," +
                    "periodicidad TEXT NOT NULL," +
                    "publicacion TEXT NOT NULL," +
                    "unidades_disponibles INTEGER NOT NULL)";
            stmt.executeUpdate(sqlRevistas);
            
            // Tabla para CDs
            String sqlCDs = "CREATE TABLE IF NOT EXISTS CDs (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nombre TEXT NOT NULL," +
                    "codigo TEXT NOT NULL," +
                    "titulo TEXT NOT NULL," +
                    "artista TEXT NOT NULL," +
                    "genero TEXT NOT NULL," +
                    "duracion TEXT NOT NULL," +
                    "numero_canciones INTEGER NOT NULL," +
                    "unidades_disponibles INTEGER NOT NULL)";
            stmt.executeUpdate(sqlCDs);
            
            // Tabla para DVDs
            String sqlDVDs = "CREATE TABLE IF NOT EXISTS DVDs (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "codigo TEXT NOT NULL," +
                    "titulo TEXT NOT NULL," +
                    "director TEXT NOT NULL," +
                    "duracion TEXT NOT NULL," +
                    "genero TEXT NOT NULL)";
            stmt.executeUpdate(sqlDVDs);
            
            System.out.println("Base de datos creada exitosamente.");
        } catch (SQLException e) {
            System.err.println("Error al crear la base de datos: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conexion != null) conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
