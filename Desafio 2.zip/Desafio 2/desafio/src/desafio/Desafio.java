//Paquete Principal
package desafio;

//Importacion de Librerias
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Importacion de clases
import desafio.agregar;
import desafio.modificar;
import desafio.listar;
import desafio.borrar;
import desafio.buscar;

public class Desafio extends JFrame {
    
    //Clase del Codigo
    public Desafio() {
        
        //Configuracion de la ventana
        super("Mediateca");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        // Crear el panel para el menú
        JPanel panelMenu = new JPanel(new GridLayout(6, 1));

        // Crear los botones del menú
        JButton btnAgregar = new JButton("Agregar material");
        JButton btnModificar = new JButton("Modificar material");
        JButton btnListar = new JButton("Listar materiales disponibles");
        JButton btnBorrar = new JButton("Borrar material");
        JButton btnBuscar = new JButton("Buscar material");
        JButton btnSalir = new JButton("Salir");

        // Agregar los botones al panel del menú
        panelMenu.add(btnAgregar);
        panelMenu.add(btnModificar);
        panelMenu.add(btnListar);
        panelMenu.add(btnBorrar);
        panelMenu.add(btnBuscar);
        panelMenu.add(btnSalir);

        // Agregar el panel del menú al JFrame
        add(panelMenu);
        
        // Cargar la imagen del logo
        ImageIcon logoIcon = new ImageIcon("src/Desafio/logo.png");
        JLabel lblLogo = new JLabel(logoIcon);

        // Agregar el logo al JFrame
        add(lblLogo, BorderLayout.NORTH);

        ////////////////////////////////////////////////////////////////////////

        // Configurar la acción para el botón "Agregar material"
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una instancia de la clase Agregar
                agregar agregar = new agregar(); // Utiliza la correcta capitalización y nombre de la clase
                // Hacer visible la ventana de agregar después de cerrar la ventana principal
                agregar.setVisible(true);
            }
        });

        // Configurar la acción para el botón "Modificar material"
        btnModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una instancia de la clase modificar
                modificar modificar = new modificar(); // Utiliza la correcta capitalización y nombre de la clase
                // Hacer visible la ventana de agregar después de cerrar la ventana principal
                modificar.setVisible(true);
            }
        });

        // Configurar la acción para el botón "Listar materiales disponibles"
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una instancia de la clase Listar
                listar listar = new listar(); // Asegúrate de utilizar la correcta capitalización y nombre de la clase
                // Hacer visible la ventana de agregar después de cerrar la ventana principal
                listar.setVisible(true);
            }
        });

        // Configurar la acción para el botón "Borrar material"
        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una instancia de la clase borrar
                borrar borrar = new borrar(); // Asegúrate de utilizar la correcta capitalización y nombre de la clase
                // Hacer visible la ventana de agregar después de cerrar la ventana principal
                borrar.setVisible(true);
            }
        });

        // Configurar la acción para el botón "Buscar material"
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una instancia de la clase buscar
                buscar buscar = new buscar(); // Asegúrate de utilizar la correcta capitalización y nombre de la clase
                // Hacer visible la ventana de agregar después de cerrar la ventana principal
                buscar.setVisible(true);
            }
        });

        // Configurar la acción para el botón "Salir"
        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Salir del programa
                System.exit(0);
            }
        });

        // Hacer visible el JFrame
        setVisible(true);
    }
    
    //Clase Principal
    public static void main(String[] args) {
        // Crear una instancia de la clase Mediateca
        SwingUtilities.invokeLater(Desafio::new);
    }
}
