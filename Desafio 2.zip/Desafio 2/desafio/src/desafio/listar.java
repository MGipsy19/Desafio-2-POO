package desafio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class listar extends JFrame {

    private JComboBox<String> cmbTipoMaterial;
    private JTextArea txtAreaLista;

    public listar() {
        super("Mediateca");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        cmbTipoMaterial = new JComboBox<>(new String[]{"Libro", "Revista", "CD", "DVD"});
        
        // Botón "Listar"
        JButton btnListar = new JButton("Listar");
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para listar los materiales del tipo seleccionado
                String tipoMaterial = (String) cmbTipoMaterial.getSelectedItem();
                listarMateriales(tipoMaterial);
            }
        });

        // Botón "Menú"
        JButton btnMenu = new JButton("Menú");
        btnMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para volver al menú principal
                dispose(); // Cerrar la ventana actual
            }
        });

        JPanel panelTipoMaterial = new JPanel();
        panelTipoMaterial.add(new JLabel("Tipo de Material:"));
        panelTipoMaterial.add(cmbTipoMaterial);

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnListar);
        panelBotones.add(btnMenu);

        txtAreaLista = new JTextArea(15, 30);
        txtAreaLista.setEditable(false); // Hacer el área de texto no editable
        JScrollPane scrollPane = new JScrollPane(txtAreaLista);

        setLayout(new BorderLayout());
        add(panelTipoMaterial, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void listarMateriales(String tipoMaterial) {
        // Lógica para listar los materiales del tipo seleccionado
        // Aquí deberías obtener los materiales de la mediateca y mostrarlos en el JTextArea
        // Por ahora, simplemente mostraremos un mensaje de ejemplo
        txtAreaLista.setText("Lista de materiales de tipo " + tipoMaterial + ":\n\n" +
                "Material 1\n" +
                "Material 2\n" +
                "Material 3\n" +
                "...");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new listar().setVisible(true);
        });
    }
}
