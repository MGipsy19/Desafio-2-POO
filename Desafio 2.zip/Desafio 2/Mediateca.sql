-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8mb4 ;
USE `mydb`;

-- -----------------------------------------------------
-- Table `mydb`.`Mediateca`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Mediateca` (
  `idMediateca` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idMediateca`)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`Libros`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Libros` (
  `idLibros` VARCHAR(6) NOT NULL,
  `idMediateca` INT NOT NULL,
  `codigo` INT,
  `titulo` VARCHAR(45),
  `autor` VARCHAR(45),
  `numero_paginas` INT,
  `editorial` VARCHAR(45),
  `ISBN` INT,
  `Ano_publicacion` INT,
  `unidades_disponibles` VARCHAR(45),
  PRIMARY KEY (`idLibros`),
  INDEX `fk_Libros_Mediateca_idx` (`idMediateca`),
  CONSTRAINT `fk_Libros_Mediateca`
    FOREIGN KEY (`idMediateca`)
    REFERENCES `mydb`.`Mediateca` (`idMediateca`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`Revistas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Revistas` (
  `idRevistas` VARCHAR(6) NOT NULL,
  `idMediateca` INT NOT NULL,
  `codigo` INT,
  `titulo` VARCHAR(45),
  `editorial` VARCHAR(45),
  `periodicidad` INT,
  `publicacion` INT,
  `unidades_disponibles` VARCHAR(45),
  PRIMARY KEY (`idRevistas`),
  INDEX `fk_Revistas_Mediateca_idx` (`idMediateca`),
  CONSTRAINT `fk_Revistas_Mediateca`
    FOREIGN KEY (`idMediateca`)
    REFERENCES `mydb`.`Mediateca` (`idMediateca`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`CDs`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CDs` (
  `idCDs` VARCHAR(6) NOT NULL,
  `idMediateca` INT NOT NULL,
  `name` VARCHAR(255),
  `codigo` INT,
  `titulo` VARCHAR(45),
  `artista` VARCHAR(45),
  `genero` VARCHAR(45),
  `duracion` INT,
  `numero_canciones` INT,
  `unidades_disponibles` INT,
  PRIMARY KEY (`idCDs`),
  INDEX `fk_CDs_Mediateca_idx` (`idMediateca`),
  CONSTRAINT `fk_CDs_Mediateca`
    FOREIGN KEY (`idMediateca`)
    REFERENCES `mydb`.`Mediateca` (`idMediateca`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`DVDs`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`DVDs` (
  `idDVDs` VARCHAR(6) NOT NULL,
  `idMediateca` INT NOT NULL,
  `Codigo` INT,
  `titulo` VARCHAR(45),
  `director` VARCHAR(45),
  `duracion` INT,  -- changed from 'duración'
  `genero` VARCHAR(45),  -- changed from 'género'
  PRIMARY KEY (`idDVDs`),
  INDEX `fk_DVDs_Mediateca_idx` (`idMediateca`),
  CONSTRAINT `fk_DVDs_Mediateca`
    FOREIGN KEY (`idMediateca`)
    REFERENCES `mydb`.`Mediateca` (`idMediateca`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

    FOREIGN KEY (`idMediateca`)
    REFERENCES `mydb`.`Mediateca` (`idMediateca`)
    ON DELETE NO ACTION
